# add-commit-push
Credit: Eric Pogue