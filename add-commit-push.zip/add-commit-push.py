import os
import sys
import subprocess

def executeCommand(cmd):
    print(cmd)
    os.system(cmd)
    print("")

print("add-commit-push")
print("")
executeCommand("git status")

response=input("Would you like to add-commit-push (y/n)?")

if response !="y":
    sys.exit()

executeCommand("git add -A")

commitMessage="Update files."
if len(sys.argv) > 2:
    commitMessage=sys.argv[2]


gitCommit="git commit -m \""+commitMessage+"\""   
executeCommand(gitCommit)
executeCommand("git push")


def move_to(sprint_5):
    try:
        os.chdir(sprint_5)
        print("Current directory:", os.getcwd())
    except FileNotFoundError:
        print("Directory not found:", sprint_5)

if __name__ == "__main__":
    if len(sys.argv) > 1:
        move_to(sys.argv[1])
    else:
        print("Usage: moveto <sprint_5>")

def execute_and_print(ls):
    """Prints the command, skips a line, and then prints the results of executing that command."""

    print(ls)
    print()  # Skip a line

    result = subprocess.run(ls, shell=True, capture_output=True, text=True)

    print(result.stdout)